#!/usr/bin/env python
import sys
sys.stdout.write("Standard output\n-0 1.001e2 0 0.001001\n1\n0.02\n")
sys.stderr.write("Standard error\n0.02\n\n\n1\n")
