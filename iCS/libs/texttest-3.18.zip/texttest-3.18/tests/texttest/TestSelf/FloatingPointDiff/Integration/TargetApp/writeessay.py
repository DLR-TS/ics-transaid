#!/usr/bin/env python
import sys
sys.stdout.write("Standard output\n-0 1e-4 0 0.001\n1\n0.02\n")
sys.stderr.write("Standard error\n0.02\n\n\n1\n")
