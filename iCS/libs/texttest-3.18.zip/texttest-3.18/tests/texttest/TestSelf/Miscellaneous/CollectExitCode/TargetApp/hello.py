#!/usr/bin/env python

import sys
print 'Hello World!'
sys.exit(42)
