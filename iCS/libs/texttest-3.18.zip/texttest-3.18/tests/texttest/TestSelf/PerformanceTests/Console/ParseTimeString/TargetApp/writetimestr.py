#!/usr/bin/env python

import time
print "some time......: 01:06:40"
time.sleep(0.5)
