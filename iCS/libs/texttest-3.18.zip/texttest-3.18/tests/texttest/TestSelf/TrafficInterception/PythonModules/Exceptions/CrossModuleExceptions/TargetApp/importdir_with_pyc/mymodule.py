
import myothermodule

def callFunction():
    raise myothermodule.BadCallException("Bad Call!")

