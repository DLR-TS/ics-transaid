#!/usr/bin/env python

import threading

def threadCount():
    return threading.activeCount()
