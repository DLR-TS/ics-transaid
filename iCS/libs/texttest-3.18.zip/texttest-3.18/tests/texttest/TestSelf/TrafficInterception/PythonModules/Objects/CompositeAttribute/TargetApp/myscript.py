#!/usr/bin/env python

import mymodule

print mymodule.object.hello + " world"

