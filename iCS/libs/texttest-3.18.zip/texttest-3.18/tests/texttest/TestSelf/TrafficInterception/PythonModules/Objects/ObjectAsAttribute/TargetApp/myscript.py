#!/usr/bin/env python

import mymodule

o = mymodule.object
print o.getValue()
print mymodule.callFunction(o)
