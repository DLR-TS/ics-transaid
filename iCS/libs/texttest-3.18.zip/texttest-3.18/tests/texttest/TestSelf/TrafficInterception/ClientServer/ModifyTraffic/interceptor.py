#!/usr/bin/env python

if __name__ == "__main__":
    import sys
    sys.stdout.write("Converted " + sys.argv[1])
