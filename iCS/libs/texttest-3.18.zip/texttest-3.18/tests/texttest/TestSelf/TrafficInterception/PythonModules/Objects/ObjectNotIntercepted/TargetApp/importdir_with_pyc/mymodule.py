
import datetime

def get_date1():
    return datetime.date(2010, 5, 4)

def get_date2():
    return datetime.date(2010, 4, 24)
