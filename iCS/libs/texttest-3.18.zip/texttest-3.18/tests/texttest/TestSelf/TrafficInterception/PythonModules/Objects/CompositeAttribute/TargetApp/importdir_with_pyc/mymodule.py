
class MyObject:
    def __init__(self):
        self.hello = "Hello"

object = MyObject()
