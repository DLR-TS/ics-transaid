#!/usr/bin/env python

import os, sys
print "Called fake", os.path.basename(sys.argv[0])
