#!/usr/bin/env python

from mymodule import *

print getValue()
print value
