
def getValue():
    return 1

value = 2
