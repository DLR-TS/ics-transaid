#!/usr/bin/env python

import package.sub.tempfile

print package.sub.tempfile.gettempdir() + " " + package.sub.tempfile.tempdir
