
def callFunction(*args, **kw):
    return repr(args) + " " + repr(kw)
