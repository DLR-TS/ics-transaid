
class MyObject:
    def __init__(self):
        self.value = "Initial Value"
    def getValue(self):
        return self.value
