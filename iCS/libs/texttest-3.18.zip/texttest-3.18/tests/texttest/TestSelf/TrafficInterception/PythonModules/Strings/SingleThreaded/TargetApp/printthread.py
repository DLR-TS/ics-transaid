#!/usr/bin/env python

import threadinfo

print "We used", threadinfo.threadCount(), "threads in this program"
