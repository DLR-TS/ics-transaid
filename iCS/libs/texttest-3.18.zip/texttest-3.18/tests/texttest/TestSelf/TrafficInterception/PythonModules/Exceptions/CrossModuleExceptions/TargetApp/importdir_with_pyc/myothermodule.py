
class BadCallException(Exception):
    pass

