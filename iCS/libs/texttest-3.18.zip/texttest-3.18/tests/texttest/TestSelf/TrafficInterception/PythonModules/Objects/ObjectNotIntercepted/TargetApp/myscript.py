#!/usr/bin/env python

import mymodule

gap = mymodule.get_date1() - mymodule.get_date2()
print gap.days, "days"
