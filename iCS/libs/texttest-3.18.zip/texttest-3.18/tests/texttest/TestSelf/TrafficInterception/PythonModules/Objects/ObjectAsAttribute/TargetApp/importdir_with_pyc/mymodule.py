
class MyObject:
    def getValue(self):
        pass

def callFunction(obj):
    return "Answer"

object = MyObject()
