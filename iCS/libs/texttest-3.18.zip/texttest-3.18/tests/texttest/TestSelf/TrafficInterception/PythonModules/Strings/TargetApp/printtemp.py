#!/usr/bin/env python

import tempfile

print tempfile.gettempdir() + " " + tempfile.tempdir
