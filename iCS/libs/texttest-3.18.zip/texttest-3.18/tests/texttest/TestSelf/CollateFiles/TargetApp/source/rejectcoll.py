#!/usr/bin/env python

# Writing nothing is interpreted as not wishing to pick up the input
