#!/usr/bin/env python

import os

# Produce fake core
file = open("core", "w")
file.write("Dummy core\n")
file.close()
