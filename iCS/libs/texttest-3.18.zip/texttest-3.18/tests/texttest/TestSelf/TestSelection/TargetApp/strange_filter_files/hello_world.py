#!/usr/bin/env python

print "This is just a simple python script printing 'Hello world!'"

print " -> Hello world!\n -> Bye now!"
