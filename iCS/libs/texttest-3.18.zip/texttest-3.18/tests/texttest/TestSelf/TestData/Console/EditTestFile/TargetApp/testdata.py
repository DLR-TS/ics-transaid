#!/usr/bin/env python

file = open("writefile", "a")
file.write("An extra line\n")
