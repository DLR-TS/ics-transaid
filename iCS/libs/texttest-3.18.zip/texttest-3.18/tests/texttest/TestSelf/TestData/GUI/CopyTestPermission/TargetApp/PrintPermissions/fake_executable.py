#!/usr/bin/env python

print "Fake executable says hello!"
