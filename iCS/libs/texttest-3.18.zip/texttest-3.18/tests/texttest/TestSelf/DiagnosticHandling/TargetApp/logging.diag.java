log4j.logger.firstdiag=OFF, file
log4j.appender.file=org.apache.log4j.FileAppender
log4j.appender.file.File=first.diag
log4j.appender.file.layout=org.apache.log4j.SimpleLayout

log4j.logger.seconddiag=OFF, file2
log4j.appender.file2=org.apache.log4j.FileAppender
log4j.appender.file2.File=second.diag
log4j.appender.file2.layout=org.apache.log4j.SimpleLayout
