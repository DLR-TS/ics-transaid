# Path to the executable
executable:DiagnosticWriter
interpreter:java

test_data_properties:myprops

[run_dependent_text]
output:Java version
[end]
