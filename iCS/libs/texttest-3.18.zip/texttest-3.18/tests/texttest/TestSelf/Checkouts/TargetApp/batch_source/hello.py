#!/usr/bin/env python
print 'Hello from batch mode!'

