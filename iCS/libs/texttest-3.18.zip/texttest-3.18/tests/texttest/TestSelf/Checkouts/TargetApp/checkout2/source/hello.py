#!/usr/bin/env python
print 'Hello from checkout2!'

