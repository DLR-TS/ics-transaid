#!/usr/bin/env python

import os, time

os.system("editor.py file")
os.system("editor.py file2")
time.sleep(3)
