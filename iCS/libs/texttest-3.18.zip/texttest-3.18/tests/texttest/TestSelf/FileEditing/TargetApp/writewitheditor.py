#!/usr/bin/env python

import os

os.system("editor.py file")
os.system("editor.py file2")
os.system("editor.py writedir")
os.system("editor.py file")
