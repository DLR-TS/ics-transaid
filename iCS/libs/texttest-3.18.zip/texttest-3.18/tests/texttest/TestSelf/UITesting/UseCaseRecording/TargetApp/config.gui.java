# Path to the executable.
executable:${TEXTTEST_CHECKOUT}/videostore.jar

interpreter:java -jar

use_case_recorder:jusecase

[run_dependent_text]
errors:colormap entry
