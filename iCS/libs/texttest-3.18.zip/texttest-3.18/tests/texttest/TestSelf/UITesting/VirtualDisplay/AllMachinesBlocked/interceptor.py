
import os

os.environ["DISPLAY"] = "realdisplay_machine:1234.0"
