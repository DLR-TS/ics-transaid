
import sys
sys.version_info = (2,3,4, "final",0)
