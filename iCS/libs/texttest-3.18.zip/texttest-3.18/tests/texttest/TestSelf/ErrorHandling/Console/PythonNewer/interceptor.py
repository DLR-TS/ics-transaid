
import sys
sys.version_info = (2,6,0, "final",0)
