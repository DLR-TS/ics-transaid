
import socket

def gethostname():
    return "a"

socket.gethostname = gethostname
