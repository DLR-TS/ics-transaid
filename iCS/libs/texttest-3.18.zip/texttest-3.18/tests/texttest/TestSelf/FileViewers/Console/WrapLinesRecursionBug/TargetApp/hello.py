#!/usr/bin/env python
import sys
print 'h' * sys.getrecursionlimit()


