#!/usr/bin/env python
import sys
print 'Hello World!'
sys.stderr.write('Error text\n')
