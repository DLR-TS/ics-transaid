#!/usr/bin/env python

import os
print 'Hello', os.getenv("MY_ENV_VAR"), 'and', os.getenv("FUNNY_SHELL_SYNTAX")


