#!/usr/bin/env python
import sys
sys.stdout.write("Standard output\nRemove this\nBut not this\n")
sys.stderr.write("Standard error\nRemove this\nBut not this\n")
