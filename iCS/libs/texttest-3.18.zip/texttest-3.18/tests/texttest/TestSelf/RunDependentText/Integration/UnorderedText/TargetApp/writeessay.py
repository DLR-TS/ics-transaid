#!/usr/bin/env python
import os

print """Some stuff
Some unordered stuff
Some other stuff
More unordered
"""
