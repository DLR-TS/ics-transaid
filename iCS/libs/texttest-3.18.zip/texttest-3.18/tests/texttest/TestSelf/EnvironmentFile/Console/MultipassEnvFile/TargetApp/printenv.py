#!/usr/bin/env python

import os
print os.getenv("MY_ENV_VAR")
