#!/usr/bin/env python

import os
print os.getenv("MY_ENV_VAR")
print os.getenv("MY_ENV_VAR_OTHER")
print os.getenv("MY_ENV_VAR_SUITE")
print os.getenv("MY_ENV_VAR_TEST")
