#!/usr/bin/env python
import os
print 'Hello', os.getenv("TO_GREET")
