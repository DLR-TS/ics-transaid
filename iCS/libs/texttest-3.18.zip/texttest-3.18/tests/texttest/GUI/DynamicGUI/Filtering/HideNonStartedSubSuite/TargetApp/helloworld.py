#!/usr/bin/env python

print "Hello world!"

file1 = open('file1.hello', 'w')
file1.write('Nothing in file1 ...\n')
file1.close()
file1 = open('file2.hello', 'w')
file1.write('Nothing in file2 ...\n')
file1.close()
file1 = open('file3.hello', 'w')
file1.write('Nothing in file3 ...\n')
file1.close()
file1 = open('file4.hello', 'w')
file1.write('Nothing in file4 ...\n')
file1.close()
