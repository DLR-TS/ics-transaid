#!/usr/bin/env python
import os
print 'Hello', os.getenv("USECASE_HOME")
