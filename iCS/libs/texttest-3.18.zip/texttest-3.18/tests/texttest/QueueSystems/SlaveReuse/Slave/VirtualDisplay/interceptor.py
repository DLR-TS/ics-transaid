
import os

def getpid():
    # my first phone number :)
    return 102283

os.getpid = getpid
