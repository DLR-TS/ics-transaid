
import socket

socket.gethostname = lambda *args: "my_machine"
