
import os
os.environ["PATH"] = ""
