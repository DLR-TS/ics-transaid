
import time

def fakeSleep(seconds):
    pass

time.sleep = fakeSleep
