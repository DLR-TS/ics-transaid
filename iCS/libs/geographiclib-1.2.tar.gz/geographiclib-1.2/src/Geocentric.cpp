/**
 * \file Geocentric.cpp
 * \brief Implementation for GeographicLib::Geocentric class
 *
 * Copyright (c) Charles Karney (2008, 2009, 2010) <charles@karney.com>
 * and licensed under the LGPL.  For more information, see
 * http://geographiclib.sourceforge.net/
 **********************************************************************/

#include "GeographicLib/Geocentric.hpp"

#define GEOGRAPHICLIB_GEOCENTRIC_CPP "$Id: Geocentric.cpp 6827 2010-05-20 19:56:18Z karney $"

RCSID_DECL(GEOGRAPHICLIB_GEOCENTRIC_CPP)
RCSID_DECL(GEOGRAPHICLIB_GEOCENTRIC_HPP)

namespace GeographicLib {

  using namespace std;

  Geocentric::Geocentric(real a, real r)
    : _a(a)
    , _r(r)
    , _f(_r != 0 ? 1 / _r : 0)
    , _e2(_f * (2 - _f))
    , _e2m(sq(1 - _f))          // 1 - _e2
    , _e2a(abs(_e2))
    , _e4a(sq(_e2))
    , _maxrad(2 * _a / numeric_limits<real>::epsilon())
  {
    if (!(_a > 0))
      throw GeographicErr("Major radius is not positive");
  }

  const Geocentric Geocentric::WGS84(Constants::WGS84_a(),
                                     Constants::WGS84_r());

  void Geocentric::Forward(real lat, real lon, real h,
                           real& x, real& y, real& z) const throw() {
    lon = lon >= 180 ? lon - 360 : lon < -180 ? lon + 360 : lon;
    real
      phi = lat * Constants::degree(),
      lam = lon * Constants::degree(),
      sphi = sin(phi),
      cphi = abs(lat) == 90 ? 0 : cos(phi),
      n = _a/sqrt(1 - _e2 * sq(sphi));
    z = ( _e2m * n + h) * sphi;
    x = (n + h) * cphi;
    y = x * (lon == -180 ? 0 : sin(lam));
    x *= (abs(lon) == 90 ? 0 : cos(lam));
  }

  void Geocentric::Reverse(real x, real y, real z,
                           real& lat, real& lon, real& h) const throw() {
    real R = Math::hypot(x, y);
    h = Math::hypot(R, z);      // Distance to center of earth
    real phi;
    if (h > _maxrad)
      // We really far away (> 12 million light years); treat the earth as a
      // point and h, above, is an acceptable approximation to the height.
      // This avoids overflow, e.g., in the computation of disc below.  It's
      // possible that h has overflowed to inf; but that's OK.
      //
      // Treat the case x, y finite, but R overflows to +inf by scaling by 2.
      phi = atan2(z/2, Math::hypot(x/2, y/2));
    else if (_e4a == 0) {
      // Treat the spherical case.  Dealing with underflow in the general case
      // with _e2 = 0 is difficult.  Origin maps to N pole same as an
      // ellipsoid.
      phi = atan2(h != 0 ? z : 1, R);
      h -= _a;
    } else {
      // Treat prolate spheroids by swapping R and z here and by switching
      // the arguments to phi = atan2(...) at the end.
      real
        p = sq(R / _a),
        q = _e2m * sq(z / _a),
        r = (p + q - _e4a) / 6;
      if (_f < 0) swap(p, q);
      if ( !(_e4a * q == 0 && r <= 0) ) {
        real
          // Avoid possible division by zero when r = 0 by multiplying
          // equations for s and t by r^3 and r, resp.
          S = _e4a * p * q / 4, // S = r^3 * s
          r2 = sq(r),
          r3 = r * r2,
          disc =  S * (2 * r3 + S);
        real u = r;
        if (disc >= 0) {
          real T3 = r3 + S;
          // Pick the sign on the sqrt to maximize abs(T3).  This minimizes
          // loss of precision due to cancellation.  The result is unchanged
          // because of the way the T is used in definition of u.
          T3 += T3 < 0 ? -sqrt(disc) : sqrt(disc); // T3 = (r * t)^3
          // N.B. cbrt always returns the real root.  cbrt(-8) = -2.
          real T = Math::cbrt(T3); // T = r * t
          // T can be zero; but then r2 / T -> 0.
          u += T + (T != 0 ? r2 / T : 0);
        } else {
          // T is complex, but the way u is defined the result is real.
          real ang = atan2(sqrt(-disc), -(S + r3));
          // There are three possible cube roots.  We choose the root which
          // avoids cancellation.  Note that disc < 0 implies that r < 0.
          u += 2 * r * cos(ang / 3);
        }
        real
          v = sqrt(sq(u) + _e4a * q), // guaranteed positive
          // Avoid loss of accuracy when u < 0.  Underflow doesn't occur in
          // e4 * q / (v - u) because u ~ e^4 when q is small and u < 0.
          uv = u < 0 ? _e4a * q / (v - u) : u + v, // u+v, guaranteed positive
          // Need to guard against w going negative due to roundoff in uv - q.
          w = max(real(0), _e2a * (uv - q) / (2 * v)),
          // Rearrange expression for k to avoid loss of accuracy due to
          // subtraction.  Division by 0 not possible because uv > 0, w >= 0.
          k = uv / (sqrt(uv + sq(w)) + w),
          k1 = _f >= 0 ? k : k - _e2,
          k2 = _f >= 0 ? k + _e2 : k,
          d = k1 * R / k2;
        phi = atan2(z/k1, R/k2);
        h = (1 - _e2m/k1) * Math::hypot(d, z);
      } else {                  // e4 * q == 0 && r <= 0
        // This leads to k = 0 (oblate, equatorial plane) and k + e^2 = 0
        // (prolate, rotation axis) and the generation of 0/0 in the general
        // formulas for phi and h.  using the general formula and division by 0
        // in formula for h.  So handle this case by taking the limits:
        // f > 0: z -> 0, k      ->   e2 * sqrt(q)/sqrt(e4 - p)
        // f < 0: R -> 0, k + e2 -> - e2 * sqrt(q)/sqrt(e4 - p)
        real
          zz = sqrt((_f >= 0 ? _e4a - p : p) / _e2m),
          xx = sqrt( _f <  0 ? _e4a - p : p        );
        phi = atan2(zz, xx);
        if (z < 0) phi = -phi; // for tiny negative z (not for prolate)
        h = - _a * (_f >= 0 ? _e2m : 1) * Math::hypot(xx, zz) / _e2a;
      }
    }
    lat = phi / Constants::degree();
    // Negative signs return lon in [-180, 180).  Assume atan2(0,0) = 0.
    lon = -atan2(-y, x) / Constants::degree();
  }

} // namespace GeographicLib
